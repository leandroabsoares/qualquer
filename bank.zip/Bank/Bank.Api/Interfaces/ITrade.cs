﻿using Bank.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bank.Api.Interfaces
{
	public interface ITrade
	{
		public static string[] SearchTradeCategories(TradeEntity Trades, double defaultValue)
		{

			var vTrade = Trades.Trade;

			string[] tradeCategory = new string[vTrade.Count];

			tradeCategory[0] = "";

			int i = 0;

			foreach (Trade trade in vTrade)
			{
				if (trade.ClientSector.ToLower() == "public")
				{
					if (trade.Value > defaultValue)
						tradeCategory[i] = "MEDIUMRISK";
					else if (trade.Value < defaultValue)
						tradeCategory[i] = "LOWRISK";
				}
				else if (trade.ClientSector.ToLower() == "private")
				{ 	
					if (trade.Value > defaultValue)
						tradeCategory[i] = "HIGHRISK";
					else
						tradeCategory[i] = "Trade Category Not Found!";
				}
				else
				{
					tradeCategory[i] = "Client Sector Not Found!";
				}
				i++;
			}

			return tradeCategory;

		}

	}
}
