﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bank.Api.Entities
{

	public class TradeEntity
	{
		public List<Trade> Trade { get; set; }
	}

	public class Trade 
	{		
		public string ClientSector { get; set; }
		public double Value { get; set; }
	}
}
