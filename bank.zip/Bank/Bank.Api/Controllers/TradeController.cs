﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bank.Api.Entities;
using Bank.Api.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Bank.Api.Controllers
{	
	[Produces("application/json")]
	[ApiController]
	[Route("[controller]")]
	public class TradeController : ControllerBase
	{


		//JSON POST
		//{       
		//    "Trade":
		//    [{
		//        "ClientSector" :"Public",
		//        "Value" : 4000.00
		//
		//	  },        
		//    {
		//        "ClientSector" :"Private",
		//        "Value" : 1000001.00
		//    }]
		//}


		[HttpPost("TradeCategories")]
		public string[] TradeCategoriesSearch(TradeEntity Trades)
		{
			return ITrade.SearchTradeCategories(Trades, 1000000);
		}
	}
}
